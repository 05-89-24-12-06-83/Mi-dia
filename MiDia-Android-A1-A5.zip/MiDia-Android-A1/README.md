Mi Día Android A5 — visual sobre A4 estable

Base: A4 funcional (alarmas nativas sin cambios).
Cambios A5:
- versionCode 5 / versionName A5
- nuevo logo de aplicación integrado como launcher icon
- no se modifica AlarmManager, AlarmService, AlarmActivity, receivers ni sincronización web

La clave de prueba estable se conserva para instalar A5 sobre A4.
