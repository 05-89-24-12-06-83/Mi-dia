package com.midia.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

public final class AlarmScheduler {
    private static final String PREFS = "midia_native";
    private static final String TASKS_JSON = "tasks_json";
    private static final String CODES = "scheduled_codes";
    private static final String COUNT = "scheduled_count";
    private static final String NEXT_MS = "next_alarm_ms";
    private static final String LAST_SYNC_MS = "last_sync_ms";

    private AlarmScheduler() {}

    public static void syncFromJson(Context context, String tasksJson) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long syncNow = System.currentTimeMillis();
        int count = 0;
        long nextMs = 0L;
        try {
            prefs.edit().putString(TASKS_JSON, tasksJson == null ? "[]" : tasksJson).apply();
            cancelAllTracked(context);

            JSONArray tasks = new JSONArray(tasksJson == null ? "[]" : tasksJson);
            long now = System.currentTimeMillis();

            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.optJSONObject(i);
                if (t == null) continue;
                if (t.optBoolean("done", false)) continue;
                if (!t.optBoolean("alarm", true)) continue;

                String id = t.optString("id", "");
                String when = t.optString("when", "");
                if (id.isEmpty() || when.isEmpty()) continue;

                long trigger;
                try { trigger = Instant.parse(when).toEpochMilli(); }
                catch (Exception ex) { continue; }

                if (trigger <= now) continue;
                if (scheduleJsonTask(context, t, trigger, false)) {
                    count++;
                    if (nextMs == 0L || trigger < nextMs) nextMs = trigger;
                }
            }
        } catch (Exception ignored) {
        } finally {
            prefs.edit()
                    .putInt(COUNT, count)
                    .putLong(NEXT_MS, nextMs)
                    .putLong(LAST_SYNC_MS, syncNow)
                    .apply();
        }
    }

    public static int getScheduledCount(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(COUNT, 0);
    }

    public static long getNextAlarmMs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(NEXT_MS, 0L);
    }

    public static long getLastSyncMs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(LAST_SYNC_MS, 0L);
    }

    public static void scheduleTest(Context context, long delayMs) {
        try {
            JSONObject t = new JSONObject();
            t.put("id", "native-test-" + System.currentTimeMillis());
            t.put("title", "Prueba Mi Día");
            t.put("notes", "El motor nativo de alarmas está funcionando.");
            t.put("sound", true);
            t.put("soundType", "soft-bell");
            t.put("volume", 80);
            t.put("vibrate", true);
            t.put("vibrationPattern", "double");
            t.put("repeat", "none");
            t.put("weekdays", new JSONArray());
            long trigger = System.currentTimeMillis() + Math.max(5_000L, delayMs);
            scheduleJsonTask(context, t, trigger, false);
        } catch (Exception ignored) {}
    }

    public static void restore(Context context) {
        SharedPreferences p =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        syncFromJson(context, p.getString(TASKS_JSON, "[]"));
    }

    public static void scheduleNextRecurrence(Context context, Intent source) {
        String repeat = source.getStringExtra("repeat");
        if (repeat == null || "none".equals(repeat)) return;

        long current = source.getLongExtra("whenMs", System.currentTimeMillis());
        long next = -1L;

        if ("5m".equals(repeat)) {
            next = System.currentTimeMillis() + 5 * 60_000L;
        } else if ("daily".equals(repeat)) {
            ZonedDateTime z = Instant.ofEpochMilli(current)
                    .atZone(ZoneId.systemDefault())
                    .plusDays(1);
            next = z.toInstant().toEpochMilli();
        } else if ("weekdays".equals(repeat)) {
            String weekdaysJson = source.getStringExtra("weekdays");
            Set<Integer> days = new HashSet<>();

            try {
                JSONArray arr =
                        new JSONArray(weekdaysJson == null ? "[]" : weekdaysJson);
                for (int i = 0; i < arr.length(); i++) {
                    days.add(arr.optInt(i, -1));
                }
            } catch (Exception ignored) {}

            ZonedDateTime base =
                    Instant.ofEpochMilli(current).atZone(ZoneId.systemDefault());

            for (int i = 1; i <= 7; i++) {
                ZonedDateTime cand = base.plusDays(i);
                int jsDay = cand.getDayOfWeek().getValue() % 7;
                if (days.contains(jsDay)) {
                    next = cand.toInstant().toEpochMilli();
                    break;
                }
            }
        }

        long until = source.getLongExtra("repeatUntilMs", 0L);
        if (next > 0 && (until == 0L || next <= until)) {
            scheduleFromIntent(context, source, next, false);
        }
    }

    public static void scheduleSnooze(Context context, Intent source) {
        long next = System.currentTimeMillis() + 5 * 60_000L;
        scheduleFromIntent(context, source, next, true);
    }

    public static void cancelById(Context context, String id, boolean snooze) {
        if (id == null || id.isEmpty()) return;

        AlarmManager am =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        int code = requestCode(id, snooze);
        Intent i = new Intent(context, AlarmReceiver.class);

        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                code,
                i,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );

        if (pi != null) {
            am.cancel(pi);
            pi.cancel();
        }
    }

    private static boolean scheduleJsonTask(
            Context context,
            JSONObject t,
            long trigger,
            boolean snooze
    ) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("id", t.optString("id", ""));
        intent.putExtra("title", t.optString("title", "Mi Día"));
        intent.putExtra("notes", t.optString("notes", ""));
        intent.putExtra("sound", t.optBoolean("sound", true));
        intent.putExtra("soundType", t.optString("soundType", "soft-bell"));
        intent.putExtra("volume", t.optInt("volume", 70));
        intent.putExtra("vibrate", t.optBoolean("vibrate", true));
        intent.putExtra(
                "vibrationPattern",
                t.optString("vibrationPattern", "standard")
        );
        intent.putExtra("repeat", t.optString("repeat", "none"));
        intent.putExtra(
                "weekdays",
                t.optJSONArray("weekdays") == null
                        ? "[]"
                        : t.optJSONArray("weekdays").toString()
        );

        long repeatUntilMs = 0L;
        try {
            String until = t.optString("repeatUntil", "");
            if (!until.isEmpty() && !"null".equals(until)) {
                repeatUntilMs = Instant.parse(until).toEpochMilli();
            }
        } catch (Exception ignored) {}

        intent.putExtra("repeatUntilMs", repeatUntilMs);
        intent.putExtra("whenMs", trigger);

        return scheduleIntent(context, intent, trigger, snooze);
    }

    private static void scheduleFromIntent(
            Context context,
            Intent source,
            long trigger,
            boolean snooze
    ) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        copyAlarmExtras(source, intent);
        intent.putExtra("whenMs", trigger);
        scheduleIntent(context, intent, trigger, snooze);
    }

    private static boolean scheduleIntent(
            Context context,
            Intent alarmIntent,
            long trigger,
            boolean snooze
    ) {
        String id = alarmIntent.getStringExtra("id");
        if (id == null || id.isEmpty()) return false;

        AlarmManager am =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        int code = requestCode(id, snooze);

        PendingIntent operation = PendingIntent.getBroadcast(
                context,
                code,
                alarmIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent show = new Intent(context, MainActivity.class);
        PendingIntent showIntent = PendingIntent.getActivity(
                context,
                code + 1_000_000,
                show,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        trigger,
                        operation
                );
            } else {
                am.setAlarmClock(
                        new AlarmManager.AlarmClockInfo(trigger, showIntent),
                        operation
                );
            }
            trackCode(context, code);
            return true;
        } catch (SecurityException ex) {
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, operation);
                trackCode(context, code);
                return true;
            } catch (Exception ignored) {
                return false;
            }
        } catch (Exception ex) {
            return false;
        }
    }

    public static void copyAlarmExtras(Intent from, Intent to) {
        if (from == null || to == null) return;

        for (String key : new String[]{
                "id", "title", "notes", "soundType",
                "vibrationPattern", "repeat", "weekdays"
        }) {
            to.putExtra(key, from.getStringExtra(key));
        }

        to.putExtra("sound", from.getBooleanExtra("sound", true));
        to.putExtra("volume", from.getIntExtra("volume", 70));
        to.putExtra("vibrate", from.getBooleanExtra("vibrate", true));
        to.putExtra(
                "repeatUntilMs",
                from.getLongExtra("repeatUntilMs", 0L)
        );
        to.putExtra(
                "whenMs",
                from.getLongExtra("whenMs", System.currentTimeMillis())
        );
    }

    private static int requestCode(String id, boolean snooze) {
        int base = Math.abs(id.hashCode() % 450_000) + 10_000;
        return snooze ? base + 500_000 : base;
    }

    private static void trackCode(Context context, int code) {
        SharedPreferences p =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        Set<String> set =
                new HashSet<>(p.getStringSet(CODES, new HashSet<>()));

        set.add(String.valueOf(code));
        p.edit().putStringSet(CODES, set).apply();
    }

    private static void cancelAllTracked(Context context) {
        SharedPreferences p =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        Set<String> codes =
                new HashSet<>(p.getStringSet(CODES, new HashSet<>()));

        AlarmManager am =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        for (String s : codes) {
            try {
                int code = Integer.parseInt(s);
                Intent i = new Intent(context, AlarmReceiver.class);

                PendingIntent pi = PendingIntent.getBroadcast(
                        context,
                        code,
                        i,
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                );

                if (pi != null) {
                    am.cancel(pi);
                    pi.cancel();
                }
            } catch (Exception ignored) {}
        }

        p.edit().putStringSet(CODES, new HashSet<>()).apply();
    }
}
