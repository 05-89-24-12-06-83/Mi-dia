# Mi Día Android A4 — motor nativo reforzado

A4 corrige el problema principal: los recordatorios guardados en la web no deben depender de que la WebView esté abierta para sonar.

Cambios A4:
- `USE_EXACT_ALARM` en Android 13+ porque las alarmas/recordatorios son función central de Mi Día.
- `SCHEDULE_EXACT_ALARM` solo para Android 12/12L.
- canal nuevo `midia_alarm_fullscreen_v4` para evitar heredar un canal desactivado de A3.
- WakeLock mantenido por `AlarmService` mientras la alarma está sonando.
- estado nativo: cantidad programada, próxima alarma, última sincronización y permisos.
- prueba nativa independiente programable desde el puente JS.
- receptor para reprogramar alarmas si cambia el permiso exacto en Android 12/12L.
- firma de prueba estable conservada: A4 se puede instalar encima de A3.
