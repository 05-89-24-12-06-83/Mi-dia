# Mi Día Android A3 — muestra azul + pantalla bloqueada

Esta revisión parte de A2 y conserva las alarmas exactas, sonido propio, vibración,
notificación activa con **Completar** y **+5 min**, recurrencias y sincronización con la PWA.

## Cambios A3
- Pantalla de alarma rediseñada según la muestra azul.
- Nuevo logotipo de libreta con casillas de selección.
- Canal de alarma nuevo de importancia alta.
- Compatibilidad reforzada con Android 15/16 para lanzar el Full Screen Intent:
  el `PendingIntent` de la pantalla de alarma opta explícitamente por el modo de
  inicio de actividad en segundo plano permitido para alarmas.
- `ForegroundService` marcado como inmediato.
- `WakeLock` breve durante el traspaso del `AlarmReceiver` al servicio de alarma.
- Conserva los controles `✓ Completar` y `+5 minutos`.
- La notificación existe solo mientras la alarma está sonando.
- Firma de prueba estable incluida en el proyecto para que A4/A5 puedan instalarse
  encima de A3 sin generar un nuevo conflicto de firma.

## Muy importante
La firma incluida es EXCLUSIVAMENTE DE PRUEBA. No debe usarse para una publicación
final en Google Play. Para producción se generará una llave privada distinta y segura.

## Primera instalación A3
A3 no puede actualizar A2 porque A2 fue firmado con una clave debug efímera de GitHub.
Desinstala A2 una sola vez e instala A3. A partir de A3, las siguientes versiones de prueba
pueden reutilizar `midia-test.keystore` y actualizarse normalmente.

## Permisos
Activa:
1. Notificaciones
2. Alarmas y recordatorios
3. Mostrar alarmas en pantalla completa
