package com.midia.app;

import android.app.ActivityOptions;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

public class AlarmService extends Service {
    public static final String ACTION_RING = "com.midia.app.RING";
    public static final String ACTION_STOP = "com.midia.app.STOP";
    public static final String CHANNEL_ID = "midia_alarm_fullscreen_v3";
    public static final int NOTIFICATION_ID = 1403;

    private SoundEngine soundEngine;
    private Vibrator vibrator;

    @Override
    public void onCreate() {
        super.onCreate();
        createAlarmChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        if (ACTION_STOP.equals(intent.getAction())) {
            stopAlarm();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!ACTION_RING.equals(intent.getAction())) {
            return START_NOT_STICKY;
        }

        Notification notification = buildActiveAlarmNotification(intent);
        startForeground(NOTIFICATION_ID, notification);

        if (intent.getBooleanExtra("sound", true)) {
            String soundType = intent.getStringExtra("soundType");
            int volume = intent.getIntExtra("volume", 70);
            soundEngine = new SoundEngine();
            soundEngine.start(soundType, volume);
        }

        if (intent.getBooleanExtra("vibrate", true)) {
            startVibration(intent.getStringExtra("vibrationPattern"));
        }

        return START_STICKY;
    }

    private void createAlarmChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Alarmas de Mi Día",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Pantalla y controles solo mientras una alarma está sonando.");
        channel.enableVibration(false);
        channel.setSound(null, null);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    private PendingIntent createFullScreenPendingIntent(Intent screenIntent) {
        Bundle optionsBundle = null;

        if (Build.VERSION.SDK_INT >= 34) {
            ActivityOptions options = ActivityOptions.makeBasic();
            options.setPendingIntentCreatorBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
            );
            optionsBundle = options.toBundle();
        }

        if (optionsBundle != null) {
            return PendingIntent.getActivity(
                    this,
                    14030,
                    screenIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE,
                    optionsBundle
            );
        }

        return PendingIntent.getActivity(
                this,
                14030,
                screenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private Notification buildActiveAlarmNotification(Intent source) {
        String title = source.getStringExtra("title");
        String notes = source.getStringExtra("notes");

        Intent screenIntent = new Intent(this, AlarmActivity.class);
        AlarmScheduler.copyAlarmExtras(source, screenIntent);
        screenIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
        );

        PendingIntent fullScreen = createFullScreenPendingIntent(screenIntent);

        Intent completeIntent = new Intent(this, AlarmActionReceiver.class);
        completeIntent.setAction(AlarmActionReceiver.ACTION_COMPLETE);
        AlarmScheduler.copyAlarmExtras(source, completeIntent);
        PendingIntent complete = PendingIntent.getBroadcast(
                this,
                14031,
                completeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent snoozeIntent = new Intent(this, AlarmActionReceiver.class);
        snoozeIntent.setAction(AlarmActionReceiver.ACTION_SNOOZE);
        AlarmScheduler.copyAlarmExtras(source, snoozeIntent);
        PendingIntent snooze = PendingIntent.getBroadcast(
                this,
                14032,
                snoozeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        b.setSmallIcon(R.drawable.ic_midia)
                .setContentTitle(title == null || title.isEmpty() ? "Mi Día" : title)
                .setContentText(notes == null || notes.isEmpty()
                        ? "Es hora de tu tarea."
                        : notes)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_MAX)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(false)
                .setContentIntent(fullScreen)
                .setFullScreenIntent(fullScreen, true)
                .addAction(new Notification.Action.Builder(
                        null, "✓ Completar", complete).build())
                .addAction(new Notification.Action.Builder(
                        null, "+5 min", snooze).build());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        return b.build();
    }

    private void startVibration(String patternName) {
        long[] pattern = VibrationPatterns.forAlarmLoop(patternName);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm =
                    (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            vibrator = vm.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }

        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.cancel();
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
        }
    }

    private void stopAlarm() {
        try {
            if (soundEngine != null) {
                soundEngine.stop();
                soundEngine = null;
            }
        } catch (Exception ignored) {}

        try {
            if (vibrator != null) {
                vibrator.cancel();
                vibrator = null;
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        stopAlarm();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
