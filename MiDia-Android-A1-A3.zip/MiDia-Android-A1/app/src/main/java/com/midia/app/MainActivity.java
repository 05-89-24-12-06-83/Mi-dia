package com.midia.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    public static final String APP_URL =
            "https://mi-dia-v12-con-sonido-repeticion-te.vercel.app";

    private static final int REQ_NOTIFICATIONS = 2001;

    private WebView webView;
    private MiDiaBridge bridge;
    private boolean specialPromptVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        bridge = new MiDiaBridge(this, webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDatabaseEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(bridge, "MiDiaAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                        "window.dispatchEvent(new Event('midia-native-ready'));",
                        null
                );
            }
        });

        webView.loadUrl(APP_URL);
        requestNotificationPermissionIfNeeded();
    }

    public void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIFICATIONS
            );
        }
    }

    public boolean notificationsEnabled() {
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.areNotificationsEnabled();
    }

    public boolean fullScreenAllowed() {
        if (Build.VERSION.SDK_INT < 34) return true;
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.canUseFullScreenIntent();
    }

    public void openFullScreenSettings() {
        if (Build.VERSION.SDK_INT < 34) return;
        try {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
        } catch (Exception ex) {
            Intent intent = new Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
        }
    }

    private void ensureSpecialAlarmAccess() {
        if (specialPromptVisible) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                specialPromptVisible = true;
                new AlertDialog.Builder(this)
                        .setTitle("Activar Alarmas y recordatorios")
                        .setMessage("Mi Día necesita este acceso para sonar exactamente a la hora programada aunque el teléfono esté bloqueado o la app esté cerrada.")
                        .setPositiveButton("Activar", (d, w) -> {
                            specialPromptVisible = false;
                            Intent intent = new Intent(
                                    Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                    Uri.parse("package:" + getPackageName())
                            );
                            startActivity(intent);
                        })
                        .setNegativeButton("Después", (d, w) -> specialPromptVisible = false)
                        .setOnCancelListener(d -> specialPromptVisible = false)
                        .show();
                return;
            }
        }

        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (!nm.canUseFullScreenIntent()) {
                specialPromptVisible = true;
                new AlertDialog.Builder(this)
                        .setTitle("Mostrar alarma en pantalla")
                        .setMessage("Activa el permiso de pantalla completa para que Mi Día muestre los botones Completar y +5 min sobre la pantalla bloqueada o mientras usas otra aplicación.")
                        .setPositiveButton("Activar", (d, w) -> {
                            specialPromptVisible = false;
                            openFullScreenSettings();
                        })
                        .setNegativeButton("Después", (d, w) -> specialPromptVisible = false)
                        .setOnCancelListener(d -> specialPromptVisible = false)
                        .show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript(
                    "window.dispatchEvent(new Event('midia-native-ready'));",
                    null
            );
        }
        webView.postDelayed(this::ensureSpecialAlarmAccess, 700);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
