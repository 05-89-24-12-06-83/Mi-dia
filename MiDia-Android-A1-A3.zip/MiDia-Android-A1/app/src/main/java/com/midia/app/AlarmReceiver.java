package com.midia.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        AlarmScheduler.scheduleNextRecurrence(context, intent);

        PowerManager.WakeLock wakeLock = null;
        try {
            PowerManager pm =
                    (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "MiDia:AlarmReceiver"
            );
            wakeLock.acquire(30_000L);
        } catch (Exception ignored) {}

        Intent service = new Intent(context, AlarmService.class);
        service.setAction(AlarmService.ACTION_RING);
        AlarmScheduler.copyAlarmExtras(intent, service);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }

        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }
}
