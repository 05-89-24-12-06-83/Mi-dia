# Mi Día Android A1

Base nativa para resolver la limitación de segundo plano de la PWA.

## Qué hace
- Mantiene la interfaz actual de Mi Día cargada desde Vercel.
- Expone `window.MiDiaAndroid` al JavaScript.
- Sincroniza las tareas guardadas en `midia.tasks` con `AlarmManager`.
- Usa `setAlarmClock()` cuando Android permite alarmas exactas.
- La alarma abre una pantalla propia, reproduce sonido y vibra aunque Mi Día no esté abierta.
- No publica una notificación de "la alarma ya ocurrió" en el panel.
- `✓ Completar` y `+5 min` se guardan y se aplican a la agenda web la próxima vez que Mi Día se abre.
- Las recurrencias diarias, por días de semana y cada 5 min se reprograman desde Android.
- Tras reiniciar el teléfono, `BootReceiver` vuelve a programar las alarmas guardadas.

## Primer arranque
Android mostrará una solicitud de acceso a **Alarmas y recordatorios**.
Debe permitirse para obtener el comportamiento exacto con la pantalla bloqueada.

## Construcción
Abrir esta carpeta con Android Studio, dejar que sincronice Gradle y ejecutar en el teléfono.

El proyecto todavía es A1 de campo. Antes de publicación en Play Store se deben completar:
- firma de producción;
- política de privacidad;
- iconos adaptativos finales;
- pruebas de Android 12–16;
- comportamiento OEM (Nubia, Xiaomi, Samsung, etc.);
- revisión de políticas de permisos de alarmas exactas.
