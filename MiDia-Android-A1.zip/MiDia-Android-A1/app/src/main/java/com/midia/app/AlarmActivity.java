package com.midia.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class AlarmActivity extends Activity {
    private MediaPlayer player;
    private Vibrator vibrator;
    private Intent alarmIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }

        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        );

        setContentView(R.layout.activity_alarm);
        alarmIntent = getIntent();

        String title = alarmIntent.getStringExtra("title");
        String notes = alarmIntent.getStringExtra("notes");

        ((TextView) findViewById(R.id.alarmTitle))
                .setText(title == null || title.isEmpty() ? "Mi Día" : title);

        ((TextView) findViewById(R.id.alarmNote))
                .setText(notes == null || notes.isEmpty()
                        ? "Tienes una función programada."
                        : notes);

        // Deja lista la próxima recurrencia aun si la app web está cerrada.
        AlarmScheduler.scheduleNextRecurrence(this, alarmIntent);

        if (alarmIntent.getBooleanExtra("sound", true)) {
            startSound(alarmIntent.getIntExtra("volume", 70));
        }

        if (alarmIntent.getBooleanExtra("vibrate", true)) {
            startVibration(alarmIntent.getStringExtra("vibrationPattern"));
        }

        Button complete = findViewById(R.id.completeButton);
        Button snooze = findViewById(R.id.snoozeButton);

        complete.setOnClickListener(v -> {
            String id = alarmIntent.getStringExtra("id");
            String repeat = alarmIntent.getStringExtra("repeat");

            if ("none".equals(repeat) || "5m".equals(repeat)) {
                AlarmScheduler.cancelCurrent(this, id, false);
            }
            AlarmScheduler.cancelCurrent(this, id, true);
            NativeActions.push(this, "complete", id);
            stopEverything();
            finishAndRemoveTask();
        });

        snooze.setOnClickListener(v -> {
            String id = alarmIntent.getStringExtra("id");
            AlarmScheduler.cancelCurrent(this, id, true);
            AlarmScheduler.scheduleSnooze(this, alarmIntent);
            NativeActions.push(this, "snooze", id);
            stopEverything();
            finishAndRemoveTask();
        });
    }

    private void startSound(int volumePercent) {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) {
                uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }

            player = new MediaPlayer();
            player.setDataSource(this, uri);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            player.setLooping(true);

            float v = Math.max(0f, Math.min(1f, volumePercent / 100f));
            player.setVolume(v, v);
            player.prepare();
            player.start();
        } catch (Exception ignored) {}
    }

    private void startVibration(String patternName) {
        long[] pattern;
        if ("short".equals(patternName)) {
            pattern = new long[]{0, 500, 300};
        } else if ("double".equals(patternName)) {
            pattern = new long[]{0, 700, 180, 700, 400};
        } else if ("triple".equals(patternName)) {
            pattern = new long[]{0, 600, 180, 600, 180, 600, 400};
        } else if ("long".equals(patternName)) {
            pattern = new long[]{0, 1500, 450};
        } else {
            pattern = new long[]{0, 800, 180, 800, 400};
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            vibrator = vm.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }

        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
        }
    }

    private void stopEverything() {
        try {
            if (player != null) {
                if (player.isPlaying()) player.stop();
                player.release();
                player = null;
            }
        } catch (Exception ignored) {}

        try {
            if (vibrator != null) vibrator.cancel();
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        stopEverything();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // La alarma solo se cierra con Completar o +5 min.
    }
}
