package com.midia.app;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

public class MiDiaBridge {
    private final Activity activity;
    private final WebView webView;

    public MiDiaBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    @JavascriptInterface
    public void syncAlarms(String tasksJson) {
        activity.runOnUiThread(() ->
                AlarmScheduler.syncFromJson(activity, tasksJson)
        );
    }

    @JavascriptInterface
    public String consumeActions() {
        return NativeActions.consume(activity);
    }

    @JavascriptInterface
    public boolean isNative() {
        return true;
    }
}
