package com.midia.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

public final class AlarmScheduler {
    private static final String PREFS = "midia_native";
    private static final String TASKS_JSON = "tasks_json";
    private static final String CODES = "scheduled_codes";

    private AlarmScheduler() {}

    public static void syncFromJson(Context context, String tasksJson) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            prefs.edit().putString(TASKS_JSON, tasksJson == null ? "[]" : tasksJson).apply();

            cancelAllTracked(context);

            JSONArray tasks = new JSONArray(tasksJson == null ? "[]" : tasksJson);
            long now = System.currentTimeMillis();

            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.optJSONObject(i);
                if (t == null) continue;
                if (t.optBoolean("done", false)) continue;
                if (!t.optBoolean("alarm", true)) continue;

                String id = t.optString("id", "");
                String when = t.optString("when", "");
                if (id.isEmpty() || when.isEmpty()) continue;

                long trigger;
                try {
                    trigger = Instant.parse(when).toEpochMilli();
                } catch (Exception ex) {
                    continue;
                }

                if (trigger <= now) continue;
                scheduleJsonTask(context, t, trigger, false);
            }
        } catch (Exception ignored) {}
    }

    public static void restore(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        syncFromJson(context, p.getString(TASKS_JSON, "[]"));
    }

    public static void scheduleNextRecurrence(Context context, Intent source) {
        String repeat = source.getStringExtra("repeat");
        if (repeat == null || repeat.equals("none")) return;

        long current = source.getLongExtra("whenMs", System.currentTimeMillis());
        long next = -1L;

        if (repeat.equals("5m")) {
            next = System.currentTimeMillis() + 5 * 60_000L;
        } else if (repeat.equals("daily")) {
            ZonedDateTime z = Instant.ofEpochMilli(current)
                    .atZone(ZoneId.systemDefault())
                    .plusDays(1);
            next = z.toInstant().toEpochMilli();
        } else if (repeat.equals("weekdays")) {
            String weekdaysJson = source.getStringExtra("weekdays");
            Set<Integer> days = new HashSet<>();
            try {
                JSONArray arr = new JSONArray(weekdaysJson == null ? "[]" : weekdaysJson);
                for (int i = 0; i < arr.length(); i++) days.add(arr.optInt(i, -1));
            } catch (Exception ignored) {}

            ZonedDateTime base = Instant.ofEpochMilli(current).atZone(ZoneId.systemDefault());
            for (int i = 1; i <= 7; i++) {
                ZonedDateTime cand = base.plusDays(i);
                int jsDay = cand.getDayOfWeek().getValue() % 7; // domingo=0
                if (days.contains(jsDay)) {
                    next = cand.toInstant().toEpochMilli();
                    break;
                }
            }
        }

        long until = source.getLongExtra("repeatUntilMs", 0L);
        if (next > 0 && (until == 0L || next <= until)) {
            scheduleFromIntent(context, source, next, false);
        }
    }

    public static void scheduleSnooze(Context context, Intent source) {
        long next = System.currentTimeMillis() + 5 * 60_000L;
        String repeat = source.getStringExtra("repeat");

        if ("5m".equals(repeat)) {
            scheduleFromIntent(context, source, next, false);
        } else {
            scheduleFromIntent(context, source, next, true);
        }
    }

    public static void cancelCurrent(Context context, String id, boolean snooze) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        int code = requestCode(id, snooze);
        Intent i = new Intent(context, AlarmActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                context, code, i,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
        if (pi != null) {
            am.cancel(pi);
            pi.cancel();
        }
    }

    private static void scheduleJsonTask(Context context, JSONObject t, long trigger, boolean snooze) {
        Intent intent = new Intent(context, AlarmActivity.class);
        intent.putExtra("id", t.optString("id", ""));
        intent.putExtra("title", t.optString("title", "Mi Día"));
        intent.putExtra("notes", t.optString("notes", ""));
        intent.putExtra("sound", t.optBoolean("sound", true));
        intent.putExtra("volume", t.optInt("volume", 70));
        intent.putExtra("vibrate", t.optBoolean("vibrate", true));
        intent.putExtra("vibrationPattern", t.optString("vibrationPattern", "standard"));
        intent.putExtra("repeat", t.optString("repeat", "none"));
        intent.putExtra("weekdays", t.optJSONArray("weekdays") == null ? "[]" : t.optJSONArray("weekdays").toString());

        long repeatUntilMs = 0L;
        try {
            String until = t.optString("repeatUntil", "");
            if (!until.isEmpty() && !"null".equals(until)) {
                repeatUntilMs = Instant.parse(until).toEpochMilli();
            }
        } catch (Exception ignored) {}

        intent.putExtra("repeatUntilMs", repeatUntilMs);
        intent.putExtra("whenMs", trigger);
        scheduleIntent(context, intent, trigger, snooze);
    }

    private static void scheduleFromIntent(Context context, Intent source, long trigger, boolean snooze) {
        Intent intent = new Intent(context, AlarmActivity.class);
        for (String key : new String[]{
                "id","title","notes","vibrationPattern","repeat","weekdays"
        }) {
            intent.putExtra(key, source.getStringExtra(key));
        }
        intent.putExtra("sound", source.getBooleanExtra("sound", true));
        intent.putExtra("volume", source.getIntExtra("volume", 70));
        intent.putExtra("vibrate", source.getBooleanExtra("vibrate", true));
        intent.putExtra("repeatUntilMs", source.getLongExtra("repeatUntilMs", 0L));
        intent.putExtra("whenMs", trigger);
        scheduleIntent(context, intent, trigger, snooze);
    }

    private static void scheduleIntent(Context context, Intent alarmIntent, long trigger, boolean snooze) {
        String id = alarmIntent.getStringExtra("id");
        if (id == null || id.isEmpty()) return;

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        int code = requestCode(id, snooze);

        PendingIntent operation = PendingIntent.getActivity(
                context,
                code,
                alarmIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent show = new Intent(context, MainActivity.class);
        PendingIntent showIntent = PendingIntent.getActivity(
                context,
                code + 1_000_000,
                show,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, operation);
            } else {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger, showIntent), operation);
            }
            trackCode(context, code);
        } catch (SecurityException ex) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, operation);
            trackCode(context, code);
        }
    }

    private static int requestCode(String id, boolean snooze) {
        int base = Math.abs(id.hashCode() % 450_000) + 10_000;
        return snooze ? base + 500_000 : base;
    }

    private static void trackCode(Context context, int code) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> set = new HashSet<>(p.getStringSet(CODES, new HashSet<>()));
        set.add(String.valueOf(code));
        p.edit().putStringSet(CODES, set).apply();
    }

    private static void cancelAllTracked(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> codes = new HashSet<>(p.getStringSet(CODES, new HashSet<>()));
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        for (String s : codes) {
            try {
                int code = Integer.parseInt(s);
                Intent i = new Intent(context, AlarmActivity.class);
                PendingIntent pi = PendingIntent.getActivity(
                        context,
                        code,
                        i,
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                );
                if (pi != null) {
                    am.cancel(pi);
                    pi.cancel();
                }
            } catch (Exception ignored) {}
        }

        p.edit().putStringSet(CODES, new HashSet<>()).apply();
    }
}
