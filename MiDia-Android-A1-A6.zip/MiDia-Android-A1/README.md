Mi Día Android A6

Base: A5 estable. Motor nativo de alarmas sin cambios.
A6: versionCode 6, versionName A6, interfaz web Liquid Glass, alarma rápida con tono nature.
Conserva firma de prueba para instalar sobre A5.
