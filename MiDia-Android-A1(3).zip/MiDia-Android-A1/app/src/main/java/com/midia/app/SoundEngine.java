package com.midia.app;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class SoundEngine {
    private static final int SAMPLE_RATE = 22050;

    private volatile boolean running = false;
    private Thread thread;
    private AudioTrack track;

    public synchronized void start(String type, int volumePercent) {
        stop();

        final short[] cycle = buildCycle(
                type == null ? "soft-bell" : type,
                Math.max(0, Math.min(100, volumePercent)) / 100.0
        );

        int minBuffer = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
        );

        track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(Math.max(minBuffer, 8192))
                .build();

        running = true;
        thread = new Thread(() -> {
            try {
                track.play();
                while (running) {
                    track.write(cycle, 0, cycle.length, AudioTrack.WRITE_BLOCKING);
                }
            } catch (Exception ignored) {
            } finally {
                try {
                    if (track != null) track.pause();
                } catch (Exception ignored) {}
            }
        }, "MiDiaAlarmSound");
        thread.start();
    }

    public synchronized void stop() {
        running = false;

        try {
            if (track != null) {
                track.stop();
                track.flush();
                track.release();
            }
        } catch (Exception ignored) {}

        track = null;

        if (thread != null) {
            thread.interrupt();
            thread = null;
        }
    }

    private static short[] buildCycle(String type, double volume) {
        PcmBuilder p = new PcmBuilder(volume * 0.30);

        addPattern(p, type);
        p.silence(260);
        addPattern(p, type); // conserva el efecto de doble sonido
        p.silence(900);

        return p.toShortArray();
    }

    private static void addPattern(PcmBuilder p, String type) {
        if ("classic".equals(type)) {
            p.tone(880, 220, "square").silence(80)
             .tone(660, 220, "square").silence(80)
             .tone(880, 280, "square");
        } else if ("digital".equals(type)) {
            p.tone(1046, 120, "square").silence(40)
             .tone(1318, 120, "square").silence(40)
             .tone(1567, 150, "square");
        } else if ("piano".equals(type)) {
            p.tone(523, 420, "triangle").silence(60)
             .tone(659, 420, "triangle").silence(60)
             .tone(784, 500, "triangle");
        } else if ("nature".equals(type)) {
            p.tone(880, 160, "sine").silence(20)
             .tone(1175, 160, "sine").silence(20)
             .tone(988, 160, "sine").silence(20)
             .tone(1318, 180, "sine");
        } else if ("sea".equals(type)) {
            p.tone(392, 320, "sine").silence(40)
             .tone(440, 320, "sine").silence(40)
             .tone(392, 320, "sine").silence(40)
             .tone(349, 380, "sine");
        } else if ("modern".equals(type)) {
            p.tone(740, 160, "triangle").silence(30)
             .tone(988, 240, "triangle");
        } else if ("friendly".equals(type)) {
            p.tone(659, 260, "sine").silence(30)
             .tone(784, 260, "sine").silence(30)
             .tone(988, 320, "sine");
        } else {
            p.tone(880, 430, "sine").silence(70)
             .tone(1320, 650, "sine");
        }
    }

    private static class PcmBuilder {
        private final ByteArrayOutputStream out = new ByteArrayOutputStream();
        private final double gain;

        PcmBuilder(double gain) {
            this.gain = Math.max(0.02, Math.min(0.40, gain));
        }

        PcmBuilder silence(int ms) {
            int count = SAMPLE_RATE * ms / 1000;
            for (int i = 0; i < count; i++) writeSample((short) 0);
            return this;
        }

        PcmBuilder tone(double freq, int ms, String wave) {
            int count = SAMPLE_RATE * ms / 1000;
            int fade = Math.min(count / 4, SAMPLE_RATE * 20 / 1000);

            for (int i = 0; i < count; i++) {
                double phase = 2.0 * Math.PI * freq * i / SAMPLE_RATE;
                double raw;

                if ("square".equals(wave)) {
                    raw = Math.sin(phase) >= 0 ? 1.0 : -1.0;
                } else if ("triangle".equals(wave)) {
                    raw = 2.0 / Math.PI * Math.asin(Math.sin(phase));
                } else {
                    raw = Math.sin(phase);
                }

                double env = 1.0;
                if (fade > 0 && i < fade) env = (double) i / fade;
                if (fade > 0 && i > count - fade) {
                    env = Math.min(env, (double) (count - i) / fade);
                }

                short sample = (short) (raw * env * gain * Short.MAX_VALUE);
                writeSample(sample);
            }
            return this;
        }

        private void writeSample(short sample) {
            out.write(sample & 0xFF);
            out.write((sample >> 8) & 0xFF);
        }

        short[] toShortArray() {
            byte[] bytes = out.toByteArray();
            short[] data = new short[bytes.length / 2];
            ByteBuffer.wrap(bytes)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .asShortBuffer()
                    .get(data);
            return data;
        }
    }
}
