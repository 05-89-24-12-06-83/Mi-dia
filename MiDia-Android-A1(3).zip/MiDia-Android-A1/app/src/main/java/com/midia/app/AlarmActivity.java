package com.midia.app;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class AlarmActivity extends Activity {
    private Intent alarmIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }

        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        );

        setContentView(R.layout.activity_alarm);
        showAlarm(getIntent());

        Button complete = findViewById(R.id.completeButton);
        Button snooze = findViewById(R.id.snoozeButton);

        complete.setOnClickListener(v -> {
            sendAlarmAction(AlarmActionReceiver.ACTION_COMPLETE);
            finishAndRemoveTask();
        });

        snooze.setOnClickListener(v -> {
            sendAlarmAction(AlarmActionReceiver.ACTION_SNOOZE);
            finishAndRemoveTask();
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showAlarm(intent);
    }

    private void showAlarm(Intent intent) {
        alarmIntent = intent;

        String title = intent.getStringExtra("title");
        String notes = intent.getStringExtra("notes");

        ((TextView) findViewById(R.id.alarmTitle))
                .setText(title == null || title.isEmpty() ? "Mi Día" : title);

        ((TextView) findViewById(R.id.alarmNote))
                .setText(notes == null || notes.isEmpty()
                        ? "Tienes una función programada."
                        : notes);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                KeyguardManager km =
                        (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (km != null && km.isKeyguardLocked()) {
                    km.requestDismissKeyguard(this, null);
                }
            } catch (Exception ignored) {}
        }
    }

    private void sendAlarmAction(String action) {
        Intent i = new Intent(this, AlarmActionReceiver.class);
        i.setAction(action);
        AlarmScheduler.copyAlarmExtras(alarmIntent, i);
        sendBroadcast(i);
    }

    @Override
    public void onBackPressed() {
        // La alarma se atiende con Completar o +5 min.
    }
}
