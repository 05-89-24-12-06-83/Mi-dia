package com.midia.app;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmActionReceiver extends BroadcastReceiver {
    public static final String ACTION_COMPLETE = "com.midia.app.COMPLETE";
    public static final String ACTION_SNOOZE = "com.midia.app.SNOOZE";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        String id = intent.getStringExtra("id");
        String repeat = intent.getStringExtra("repeat");

        if (ACTION_SNOOZE.equals(action)) {
            // Para "cada 5 min" la siguiente alarma ya quedó programada.
            if (!"5m".equals(repeat)) {
                AlarmScheduler.scheduleSnooze(context, intent);
            }
            NativeActions.push(context, "snooze", id);
        } else if (ACTION_COMPLETE.equals(action)) {
            // Las recurrencias diaria/semanal siguen; las de 5 min se detienen.
            if ("none".equals(repeat) || "5m".equals(repeat) || repeat == null) {
                AlarmScheduler.cancelById(context, id, false);
            }
            AlarmScheduler.cancelById(context, id, true);
            NativeActions.push(context, "complete", id);
        }

        Intent stop = new Intent(context, AlarmService.class);
        stop.setAction(AlarmService.ACTION_STOP);
        context.startService(stop);

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(AlarmService.NOTIFICATION_ID);
    }
}
