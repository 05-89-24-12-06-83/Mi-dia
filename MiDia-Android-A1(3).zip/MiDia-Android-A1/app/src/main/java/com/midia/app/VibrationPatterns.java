package com.midia.app;

public final class VibrationPatterns {
    private VibrationPatterns() {}

    public static long[] forName(String name) {
        if ("short".equals(name)) {
            return new long[]{0, 500};
        }
        if ("double".equals(name)) {
            return new long[]{0, 700, 180, 700};
        }
        if ("triple".equals(name)) {
            return new long[]{0, 600, 180, 600, 180, 600};
        }
        if ("long".equals(name)) {
            return new long[]{0, 1500};
        }
        return new long[]{0, 800, 180, 800};
    }

    public static long[] forAlarmLoop(String name) {
        if ("short".equals(name)) {
            return new long[]{0, 500, 650};
        }
        if ("double".equals(name)) {
            return new long[]{0, 700, 180, 700, 700};
        }
        if ("triple".equals(name)) {
            return new long[]{0, 600, 180, 600, 180, 600, 750};
        }
        if ("long".equals(name)) {
            return new long[]{0, 1500, 800};
        }
        return new long[]{0, 800, 180, 800, 700};
    }
}
