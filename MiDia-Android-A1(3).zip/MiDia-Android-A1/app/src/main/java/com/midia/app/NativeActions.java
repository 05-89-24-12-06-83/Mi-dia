package com.midia.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public final class NativeActions {
    private static final String PREFS = "midia_native";
    private static final String KEY = "pending_actions";

    private NativeActions() {}

    public static synchronized void push(Context context, String action, String id) {
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(p.getString(KEY, "[]"));
            JSONObject obj = new JSONObject();
            obj.put("action", action);
            obj.put("id", id);
            obj.put("at", System.currentTimeMillis());
            arr.put(obj);
            p.edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static synchronized String consume(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = p.getString(KEY, "[]");
        p.edit().putString(KEY, "[]").apply();
        return value;
    }
}
