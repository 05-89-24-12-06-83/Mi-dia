package com.midia.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Programa la siguiente recurrencia antes de iniciar la alarma actual.
        AlarmScheduler.scheduleNextRecurrence(context, intent);

        Intent service = new Intent(context, AlarmService.class);
        service.setAction(AlarmService.ACTION_RING);
        AlarmScheduler.copyAlarmExtras(intent, service);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }
    }
}
