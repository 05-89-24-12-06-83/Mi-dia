package com.midia.app;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

public class MiDiaBridge {
    private final MainActivity activity;
    private final WebView webView;

    public MiDiaBridge(MainActivity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    @JavascriptInterface
    public void syncAlarms(String tasksJson) {
        activity.runOnUiThread(() ->
                AlarmScheduler.syncFromJson(activity, tasksJson)
        );
    }

    @JavascriptInterface
    public String consumeActions() {
        return NativeActions.consume(activity);
    }

    @JavascriptInterface
    public boolean isNative() {
        return true;
    }

    @JavascriptInterface
    public boolean notificationsEnabled() {
        return activity.notificationsEnabled();
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
        activity.runOnUiThread(activity::requestNotificationPermissionIfNeeded);
    }

    @JavascriptInterface
    public boolean previewVibration(String patternName) {
        try {
            final long[] pattern = VibrationPatterns.forName(patternName);
            activity.runOnUiThread(() -> {
                Vibrator vibrator;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    VibratorManager vm = (VibratorManager)
                            activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                    vibrator = vm.getDefaultVibrator();
                } else {
                    vibrator = (Vibrator)
                            activity.getSystemService(Context.VIBRATOR_SERVICE);
                }
                if (vibrator != null && vibrator.hasVibrator()) {
                    vibrator.cancel();
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
                }
            });
            return true;
        } catch (Exception ex) {
            return false;
        }
    }
}
