# Mi Día Android A2

Correcciones sobre A1 para pruebas reales en Android:

- Alarma exacta en segundo plano mediante `AlarmManager`.
- `AlarmReceiver` inicia un servicio de alarma en primer plano.
- La alarma muestra una notificación **solo mientras está sonando**.
- Esa notificación incluye **✓ Completar** y **+5 min**.
- Usa `FullScreenIntent` para mostrar la pantalla de alarma sobre la pantalla bloqueada.
- Al completar o aplazar se elimina inmediatamente la notificación activa.
- No queda una notificación residual indicando que "ya hubo una alarma".
- Sonido nativo propio de Mi Día según el tono seleccionado en el formulario.
- Se elimina el uso del tono de alarma predeterminado del teléfono.
- Vibración nativa directa.
- La prueba de vibración desde la pantalla web usa el puente Android; no depende de Web Notifications.
- Las alarmas recurrentes y el reinicio del teléfono siguen soportados.

## Permisos de primera ejecución
Mi Día puede pedir:
1. Notificaciones.
2. Alarmas y recordatorios.
3. Mostrar alarmas en pantalla completa.

Los tres deben estar habilitados para obtener el comportamiento completo.

## Compilación
El workflow de GitHub actual puede seguir usando el nombre `MiDia-Android-A1.zip`.
Para no tener que cambiar el workflow, el ZIP de reemplazo conserva ese nombre,
aunque internamente la aplicación es versión `A2`.
